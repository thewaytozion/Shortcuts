// **********************************
// *   main.js for HTML Sandbox     *
// *        by thewaytozion         *
// **********************************

// Add you custom JS below

// wait for all DOMs loaded 
document.addEventListener("DOMContentLoaded", function(event) { 
  
});
