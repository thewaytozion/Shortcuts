// **********************************
// *  config.js for HTML Sandbox    *
// *        by thewaytozion         *
// **********************************

// *******************************************************************
// * GENERAL                                                         *
// *                                                                 *
// * IN GERNERAL  avoid spaces before and after the equal sign "="   *
// *******************************************************************

var username="thewaytozion";