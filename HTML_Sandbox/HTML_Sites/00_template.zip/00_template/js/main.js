// **********************************
// *   main.js for HTML Sandbox     *
// *        by thewaytozion         *
// **********************************

// Add you custom JS below

//document.getElementById("icon").src="img/icons/4n.png";

// wait for all DOMs loaded 
document.addEventListener("DOMContentLoaded", function(event) { 
// add your changes after al DOMs are loaded
    document.getElementById("username").innerHTML = username;

});
